<?php

include "koneksi.php";


// Ambil ID data
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;


// Ambil RT dari data sebelum dihapus
$query = mysqli_query(
    $koneksi,
    "SELECT rt_id FROM warga WHERE id = $id"
);


if (mysqli_num_rows($query) == 0) {

    die("Data tidak ditemukan.");

}


$data = mysqli_fetch_assoc($query);

$rt_id = $data['rt_id'];


// Hapus data
mysqli_query(
    $koneksi,
    "DELETE FROM warga WHERE id = $id"
);


// Kembali ke data RT
header(
    "Location: data_bmw.php?rt_id=$rt_id"
);

exit;

?>