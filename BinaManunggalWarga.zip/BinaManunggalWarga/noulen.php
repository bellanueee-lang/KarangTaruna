<?php

session_start();

if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}


/* =========================
   KONEKSI DATABASE
========================= */

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "db_bmw"
);

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}


/* =========================
   HAPUS NOTULEN
========================= */

if (isset($_GET["hapus"])) {

    $id = intval($_GET["hapus"]);

    $stmt = $conn->prepare(
        "DELETE FROM notulen WHERE id = ?"
    );

    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: notulen.php");
    exit;
}


/* =========================
   TAMBAH NOTULEN
========================= */

if (isset($_POST["tambah"])) {

    $kegiatan_id      = !empty($_POST["kegiatan_id"])
                       ? intval($_POST["kegiatan_id"])
                       : null;

    $tanggal           = $_POST["tanggal"];
    $waktu             = !empty($_POST["waktu"])
                       ? $_POST["waktu"]
                       : null;

    $tempat            = $_POST["tempat"];
    $pimpinan          = $_POST["pimpinan"];
    $notulis           = $_POST["notulis"];
    $peserta           = intval($_POST["peserta"]);
    $agenda            = $_POST["agenda"];
    $hasil_pembahasan  = $_POST["hasil_pembahasan"];
    $keputusan         = $_POST["keputusan"];
    $tindak_lanjut     = $_POST["tindak_lanjut"];


    $stmt = $conn->prepare(
        "INSERT INTO notulen
        (
            kegiatan_id,
            tanggal,
            waktu,
            tempat,
            pimpinan,
            notulis,
            peserta,
            agenda,
            hasil_pembahasan,
            keputusan,
            tindak_lanjut
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );


    $stmt->bind_param(
        "isssssissss",
        $kegiatan_id,
        $tanggal,
        $waktu,
        $tempat,
        $pimpinan,
        $notulis,
        $peserta,
        $agenda,
        $hasil_pembahasan,
        $keputusan,
        $tindak_lanjut
    );


    $stmt->execute();

    header("Location: notulen.php");
    exit;
}


/* =========================
   EDIT NOTULEN
========================= */

if (isset($_POST["edit"])) {

    $id               = intval($_POST["id"]);

    $kegiatan_id      = !empty($_POST["kegiatan_id"])
                      ? intval($_POST["kegiatan_id"])
                      : null;

    $tanggal          = $_POST["tanggal"];

    $waktu            = !empty($_POST["waktu"])
                      ? $_POST["waktu"]
                      : null;

    $tempat           = $_POST["tempat"];
    $pimpinan         = $_POST["pimpinan"];
    $notulis          = $_POST["notulis"];
    $peserta          = intval($_POST["peserta"]);
    $agenda           = $_POST["agenda"];
    $hasil_pembahasan = $_POST["hasil_pembahasan"];
    $keputusan        = $_POST["keputusan"];
    $tindak_lanjut    = $_POST["tindak_lanjut"];


    $stmt = $conn->prepare(
        "UPDATE notulen SET

            kegiatan_id = ?,
            tanggal = ?,
            waktu = ?,
            tempat = ?,
            pimpinan = ?,
            notulis = ?,
            peserta = ?,
            agenda = ?,
            hasil_pembahasan = ?,
            keputusan = ?,
            tindak_lanjut = ?

         WHERE id = ?"
    );


    $stmt->bind_param(
        "isssssissssi",
        $kegiatan_id,
        $tanggal,
        $waktu,
        $tempat,
        $pimpinan,
        $notulis,
        $peserta,
        $agenda,
        $hasil_pembahasan,
        $keputusan,
        $tindak_lanjut,
        $id
    );


    $stmt->execute();

    header("Location: notulen.php");
    exit;
}


/* =========================
   DATA EDIT
========================= */

$dataEdit = null;

if (isset($_GET["edit"])) {

    $id = intval($_GET["edit"]);

    $stmt = $conn->prepare(
        "SELECT * FROM notulen WHERE id = ?"
    );

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $hasil = $stmt->get_result();

    $dataEdit = $hasil->fetch_assoc();
}


/* =========================
   PENCARIAN
========================= */

$cari = "";

if (isset($_GET["cari"])) {
    $cari = trim($_GET["cari"]);
}


if ($cari != "") {

    $stmt = $conn->prepare(
        "SELECT
            notulen.*,
            kegiatan.nama_kegiatan

         FROM notulen

         LEFT JOIN kegiatan
         ON notulen.kegiatan_id = kegiatan.id

         WHERE
            kegiatan.nama_kegiatan LIKE ?
            OR notulen.tempat LIKE ?
            OR notulen.pimpinan LIKE ?
            OR notulen.notulis LIKE ?

         ORDER BY notulen.id DESC"
    );


    $keyword = "%" . $cari . "%";


    $stmt->bind_param(
        "ssss",
        $keyword,
        $keyword,
        $keyword,
        $keyword
    );


    $stmt->execute();

    $dataNotulen = $stmt->get_result();

} else {

    $dataNotulen = $conn->query(
        "SELECT
            notulen.*,
            kegiatan.nama_kegiatan

         FROM notulen

         LEFT JOIN kegiatan
         ON notulen.kegiatan_id = kegiatan.id

         ORDER BY notulen.id DESC"
    );
}


/* =========================
   DATA KEGIATAN
========================= */

$dataKegiatan = $conn->query(
    "SELECT *
     FROM kegiatan
     ORDER BY tanggal DESC"
);

?>


<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Notulen - Karang Taruna BMW</title>


<style>

/* =========================
   RESET
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}


body {
    background: #f3f8f9;
    color: #333;
}


/* =========================
   SIDEBAR
========================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;
    height: 100vh;

    background: #087f8c;

    color: white;

    padding: 25px 18px;
}


.brand {

    text-align: center;

    padding-bottom: 25px;

    border-bottom:
        1px solid
        rgba(255,255,255,.2);
}


.brand h2 {
    font-size: 21px;
    margin-bottom: 5px;
}


.brand p {
    font-size: 12px;
    opacity: .85;
}


.menu {
    margin-top: 25px;
}


.menu a {

    display: flex;

    align-items: center;

    gap: 12px;

    color: white;

    text-decoration: none;

    padding: 13px 15px;

    margin-bottom: 7px;

    border-radius: 10px;

    font-size: 14px;
}


.menu a:hover,
.menu a.active {

    background:
        rgba(255,255,255,.18);
}


.menu-icon {

    width: 25px;

    text-align: center;

    font-size: 18px;
}


.logout {

    position: absolute;

    bottom: 25px;

    left: 18px;
    right: 18px;

    background: white;

    color: #087f8c !important;

    justify-content: center;

    font-weight: bold;
}


/* =========================
   MAIN
========================= */

.main {

    margin-left: 250px;

    padding: 30px;
}


.topbar {

    background: white;

    padding: 22px 25px;

    border-radius: 15px;

    margin-bottom: 25px;

    box-shadow:
        0 4px 15px
        rgba(0,0,0,.05);

    display: flex;

    justify-content: space-between;

    align-items: center;
}


.topbar h1 {

    color: #087f8c;

    font-size: 25px;
}


.topbar p {

    color: #777;

    font-size: 13px;

    margin-top: 5px;
}


.user {
    text-align: right;
}


.user strong {
    color: #087f8c;
}


/* =========================
   BOX
========================= */

.box {

    background: white;

    padding: 25px;

    border-radius: 15px;

    margin-bottom: 25px;

    box-shadow:
        0 4px 15px
        rgba(0,0,0,.05);
}


.box h2 {

    color: #087f8c;

    font-size: 19px;

    margin-bottom: 20px;
}


/* =========================
   FORM
========================= */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 18px;
}


.form-group label {

    display: block;

    font-size: 13px;

    font-weight: bold;

    margin-bottom: 7px;
}


.form-group input,
.form-group select,
.form-group textarea {

    width: 100%;

    padding: 11px;

    border:
        1px solid #ddd;

    border-radius: 9px;

    outline: none;

    font-size: 13px;
}


.form-group textarea {

    min-height: 100px;

    resize: vertical;
}


.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #087f8c;
}


.full {

    grid-column: 1 / -1;
}


.button {

    border: none;

    padding: 12px 20px;

    border-radius: 9px;

    cursor: pointer;

    font-weight: bold;

    margin-top: 18px;
}


.button-tambah {

    background: #087f8c;

    color: white;
}


.button-edit {

    background: #f0a500;

    color: white;
}


.button-batal {

    display: inline-block;

    background: #ddd;

    color: #444;

    text-decoration: none;

    margin-left: 5px;
}


/* =========================
   SEARCH
========================= */

.search {

    display: flex;

    gap: 10px;

    margin-bottom: 20px;
}


.search input {

    flex: 1;

    padding: 12px 15px;

    border:
        1px solid #ddd;

    border-radius: 9px;

    outline: none;
}


.search button {

    padding: 12px 20px;

    border: none;

    border-radius: 9px;

    background: #087f8c;

    color: white;

    font-weight: bold;

    cursor: pointer;
}


.search a {

    padding: 12px 20px;

    background: #ddd;

    color: #444;

    text-decoration: none;

    border-radius: 9px;
}


/* =========================
   TABLE
========================= */

.table-wrapper {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 900px;
}


th {

    background: #087f8c;

    color: white;

    padding: 13px;

    text-align: left;

    font-size: 13px;
}


td {

    padding: 13px;

    border-bottom:
        1px solid #eee;

    font-size: 13px;

    vertical-align: top;
}


tr:hover td {

    background: #f5fbfc;
}


.aksi {

    display: flex;

    gap: 7px;
}


.btn-edit {

    background: #f0a500;

    color: white;

    padding: 7px 11px;

    border-radius: 7px;

    text-decoration: none;

    font-size: 12px;
}


.btn-hapus {

    background: #dc3545;

    color: white;

    padding: 7px 11px;

    border-radius: 7px;

    text-decoration: none;

    font-size: 12px;
}


/* =========================
   RESPONSIVE
========================= */

@media(max-width: 800px) {

    .sidebar {
        width: 70px;
        padding: 20px 10px;
    }

    .brand h2,
    .brand p,
    .menu a span:not(.menu-icon) {
        display: none;
    }

    .menu a {
        justify-content: center;
    }

    .main {
        margin-left: 70px;
        padding: 20px;
    }

    .form-grid {
        grid-template-columns: 1fr;
    }

    .topbar {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }

}

</style>

</head>


<body>


<!-- =========================
     SIDEBAR
========================= -->

<aside class="sidebar">

    <div class="brand">

        <h2>
            Karang Taruna BMW
        </h2>

        <p>
            Bina Manunggal Warga
        </p>

    </div>


    <nav class="menu">

        <a href="dashboard.php">

            <span class="menu-icon">🏠</span>

            <span>Dashboard</span>

        </a>


        <a href="warga.php">

            <span class="menu-icon">👥</span>

            <span>Data Warga</span>

        </a>


        <a href="pengurus.php">

            <span class="menu-icon">👤</span>

            <span>Pengurus</span>

        </a>


        <a href="kegiatan.php">

            <span class="menu-icon">📅</span>

            <span>Kegiatan</span>

        </a>


        <a
            href="notulen.php"
            class="active"
        >

            <span class="menu-icon">📝</span>

            <span>Notulen</span>

        </a>


        <a href="rt.php">

            <span class="menu-icon">🏘️</span>

            <span>Data RT</span>

        </a>


        <a href="transaksi.php">

            <span class="menu-icon">💰</span>

            <span>Transaksi</span>

        </a>

    </nav>


    <a
        href="logout.php"
        class="menu logout"
    >

        <span class="menu-icon">🚪</span>

        <span>Keluar</span>

    </a>

</aside>



<!-- =========================
     MAIN
========================= -->

<main class="main">


    <div class="topbar">

        <div>

            <h1>
                Data Notulen
            </h1>

            <p>
                Kelola hasil rapat dan kegiatan Karang Taruna BMW
            </p>

        </div>


        <div class="user">

            Login sebagai:

            <strong>
                <?= htmlspecialchars(
                    $_SESSION["nama"] ?? "Admin"
                ) ?>
            </strong>

        </div>

    </div>



    <!-- =========================
         FORM TAMBAH / EDIT
    ========================= -->

    <div class="box">

        <?php if ($dataEdit) { ?>

            <h2>
                ✏️ Edit Notulen
            </h2>

        <?php } else { ?>

            <h2>
                ➕ Tambah Notulen
            </h2>

        <?php } ?>


        <form method="POST">


            <?php if ($dataEdit) { ?>

                <input
                    type="hidden"
                    name="id"
                    value="<?= $dataEdit["id"] ?>"
                >

            <?php } ?>


            <div class="form-grid">


                <!-- KEGIATAN -->

                <div class="form-group">

                    <label>
                        Kegiatan
                    </label>

                    <select
                        name="kegiatan_id"
                    >

                        <option value="">
                            -- Pilih Kegiatan --
                        </option>


                        <?php

                        $dataKegiatan->data_seek(0);

                        while (
                            $kegiatan =
                            $dataKegiatan->fetch_assoc()
                        ) {

                        ?>

                            <option
                                value="<?= $kegiatan["id"] ?>"
                                <?= (
                                    $dataEdit &&
                                    $dataEdit["kegiatan_id"]
                                    == $kegiatan["id"]
                                )
                                ? "selected"
                                : "" ?>
                            >

                                <?= htmlspecialchars(
                                    $kegiatan["nama_kegiatan"]
                                ) ?>

                            </option>

                        <?php } ?>

                    </select>

                </div>



                <!-- TANGGAL -->

                <div class="form-group">

                    <label>
                        Tanggal
                    </label>

                    <input
                        type="date"
                        name="tanggal"
                        value="<?= $dataEdit
                            ? $dataEdit["tanggal"]
                            : date("Y-m-d") ?>"
                        required
                    >

                </div>



                <!-- WAKTU -->

                <div class="form-group">

                    <label>
                        Waktu
                    </label>

                    <input
                        type="time"
                        name="waktu"
                        value="<?= $dataEdit
                            ? $dataEdit["waktu"]
                            : "" ?>"
                    >

                </div>



                <!-- TEMPAT -->

                <div class="form-group">

                    <label>
                        Tempat
                    </label>

                    <input
                        type="text"
                        name="tempat"
                        placeholder="Contoh: Balai Desa"
                        value="<?= $dataEdit
                            ? htmlspecialchars(
                                $dataEdit["tempat"]
                              )
                            : "" ?>"
                    >

                </div>



                <!-- PIMPINAN -->

                <div class="form-group">

                    <label>
                        Pimpinan Rapat
                    </label>

                    <input
                        type="text"
                        name="pimpinan"
                        placeholder="Nama pimpinan rapat"
                        value="<?= $dataEdit
                            ? htmlspecialchars(
                                $dataEdit["pimpinan"]
                              )
                            : "" ?>"
                    >

                </div>



                <!-- NOTULIS -->

                <div class="form-group">

                    <label>
                        Notulis
                    </label>

                    <input
                        type="text"
                        name="notulis"
                        placeholder="Nama notulis"
                        value="<?= $dataEdit
                            ? htmlspecialchars(
                                $dataEdit["notulis"]
                              )
                            : "" ?>"
                    >

                </div>



                <!-- PESERTA -->

                <div class="form-group">

                    <label>
                        Jumlah Peserta
                    </label>

                    <input
                        type="number"
                        name="peserta"
                        min="0"
                        value="<?= $dataEdit
                            ? $dataEdit["peserta"]
                            : 0 ?>"
                    >

                </div>



                <!-- AGENDA -->

                <div class="form-group full">

                    <label>
                        Agenda
                    </label>

                    <textarea
                        name="agenda"
                        placeholder="Tuliskan agenda rapat..."
                    ><?= $dataEdit
                        ? htmlspecialchars(
                            $dataEdit["agenda"]
                          )
                        : "" ?></textarea>

                </div>



                <!-- HASIL PEMBAHASAN -->

                <div class="form-group full">

                    <label>
                        Hasil Pembahasan
                    </label>

                    <textarea
                        name="hasil_pembahasan"
                        placeholder="Tuliskan hasil pembahasan..."
                    ><?= $dataEdit
                        ? htmlspecialchars(
                            $dataEdit["hasil_pembahasan"]
                          )
                        : "" ?></textarea>

                </div>



                <!-- KEPUTUSAN -->

                <div class="form-group full">

                    <label>
                        Keputusan
                    </label>

                    <textarea
                        name="keputusan"
                        placeholder="Tuliskan keputusan rapat..."
                    ><?= $dataEdit
                        ? htmlspecialchars(
                            $dataEdit["keputusan"]
                          )
                        : "" ?></textarea>

                </div>



                <!-- TINDAK LANJUT -->

                <div class="form-group full">

                    <label>
                        Tindak Lanjut
                    </label>

                    <textarea
                        name="tindak_lanjut"
                        placeholder="Tuliskan tindak lanjut..."
                    ><?= $dataEdit
                        ? htmlspecialchars(
                            $dataEdit["tindak_lanjut"]
                          )
                        : "" ?></textarea>

                </div>


            </div>



            <?php if ($dataEdit) { ?>

                <button
                    type="submit"
                    name="edit"
                    class="button button-edit"
                >
                    💾 Simpan Perubahan
                </button>


                <a
                    href="notulen.php"
                    class="button button-batal"
                >
                    Batal
                </a>

            <?php } else { ?>

                <button
                    type="submit"
                    name="tambah"
                    class="button button-tambah"
                >
                    ➕ Simpan Notulen
                </button>

            <?php } ?>


        </form>

    </div>



    <!-- =========================
         DAFTAR NOTULEN
    ========================= -->

    <div class="box">

        <h2>
            📋 Daftar Notulen
        </h2>


        <form
            method="GET"
            class="search"
        >

            <input
                type="text"
                name="cari"
                placeholder="Cari kegiatan, tempat, pimpinan, atau notulis..."
                value="<?= htmlspecialchars($cari) ?>"
            >


            <button type="submit">
                🔍 Cari
            </button>


            <?php if ($cari != "") { ?>

                <a href="notulen.php">
                    Reset
                </a>

            <?php } ?>

        </form>



        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Kegiatan</th>

                        <th>Tanggal</th>

                        <th>Waktu</th>

                        <th>Tempat</th>

                        <th>Pimpinan</th>

                        <th>Notulis</th>

                        <th>Peserta</th>

                        <th>Aksi</th>

                    </tr>

                </thead>


                <tbody>

                <?php

                $no = 1;


                if (
                    $dataNotulen &&
                    $dataNotulen->num_rows > 0
                ) {


                    while (
                        $row =
                        $dataNotulen->fetch_assoc()
                    ) {

                ?>

                    <tr>


                        <td>
                            <?= $no++ ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $row["nama_kegiatan"]
                                ?? "-"
                            ) ?>
                        </td>


                        <td>
                            <?= date(
                                "d-m-Y",
                                strtotime(
                                    $row["tanggal"]
                                )
                            ) ?>
                        </td>


                        <td>
                            <?= $row["waktu"]
                                ? htmlspecialchars(
                                    $row["waktu"]
                                  )
                                : "-" ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $row["tempat"]
                                ?? "-"
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $row["pimpinan"]
                                ?? "-"
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $row["notulis"]
                                ?? "-"
                            ) ?>
                        </td>


                        <td>
                            <?= intval(
                                $row["peserta"]
                            ) ?>
                            orang
                        </td>


                        <td>

                            <div class="aksi">


                                <a
                                    href="notulen.php?edit=<?= $row["id"] ?>"
                                    class="btn-edit"
                                >
                                    ✏️ Edit
                                </a>


                                <a
                                    href="notulen.php?hapus=<?= $row["id"] ?>"
                                    class="btn-hapus"
                                    onclick="return confirm('Yakin ingin menghapus notulen ini?')"
                                >
                                    🗑️ Hapus
                                </a>


                            </div>

                        </td>


                    </tr>


                <?php

                    }

                } else {

                ?>


                    <tr>

                        <td
                            colspan="9"
                            style="
                                text-align:center;
                                padding:30px;
                            "
                        >

                            Belum ada data notulen.

                        </td>

                    </tr>


                <?php } ?>


                </tbody>

            </table>

        </div>

    </div>


</main>


</body>

</html>