```php
<?php

session_start();

// Cek apakah sudah login
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Data BMW</title>

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            background: #f8f1e7;
            color: #4e342e;
        }

        /* =========================
           HEADER
        ========================== */

        .header {
            background: #5d4037;
            color: white;

            padding: 20px 40px;

            display: flex;
            justify-content: space-between;
            align-items: center;

            box-shadow: 0 4px 15px rgba(78,52,46,0.15);
        }

        .logo h1 {
            font-size: 28px;
            letter-spacing: 2px;
        }

        .logo p {
            font-size: 12px;
            opacity: 0.8;
            margin-top: 4px;
        }

        /* =========================
           CONTAINER
        ========================== */

        .container {
            max-width: 1100px;
            margin: 40px auto;
            padding: 0 25px;
        }

        .title {
            margin-bottom: 30px;
        }

        .title h2 {
            color: #5d4037;
            font-size: 30px;
            margin-bottom: 8px;
        }

        .title p {
            color: #8d6e63;
        }

        /* =========================
           RT CARDS
        ========================== */

        .rt-container {
            display: grid;

            grid-template-columns:
                repeat(2, 1fr);

            gap: 25px;
        }

        .rt-card {
            background: white;

            padding: 30px;

            border-radius: 20px;

            box-shadow:
                0 8px 25px
                rgba(78,52,46,0.10);

            transition: 0.25s;

            border: 1px solid #eee0d5;
        }

        .rt-card:hover {
            transform: translateY(-5px);

            box-shadow:
                0 12px 30px
                rgba(78,52,46,0.16);
        }

        .rt-icon {
            width: 60px;
            height: 60px;

            display: flex;

            justify-content: center;
            align-items: center;

            background: #eee0d5;

            border-radius: 15px;

            font-size: 28px;

            margin-bottom: 20px;
        }

        .rt-card h3 {
            color: #5d4037;

            font-size: 23px;

            margin-bottom: 10px;
        }

        .rt-card p {
            color: #8d6e63;

            line-height: 1.5;

            margin-bottom: 20px;
        }

        .btn-rt {
            display: inline-block;

            padding: 11px 20px;

            background: #6d4c41;

            color: white;

            text-decoration: none;

            border-radius: 10px;

            font-weight: bold;

            transition: 0.2s;
        }

        .btn-rt:hover {
            background: #4e342e;
        }

        /* =========================
           BACK BUTTON
        ========================== */

        .back-dashboard {
            display: inline-block;

            margin-top: 30px;

            padding: 12px 20px;

            background: white;

            color: #6d4c41;

            text-decoration: none;

            border: 1px solid #d7ccc8;

            border-radius: 10px;

            font-weight: bold;

            transition: 0.2s;
        }

        .back-dashboard:hover {
            background: #6d4c41;

            color: white;
        }

        /* =========================
           FOOTER
        ========================== */

        .footer {
            text-align: center;

            margin-top: 50px;

            padding: 20px;

            color: #8d6e63;

            font-size: 13px;
        }

        /* =========================
           RESPONSIVE
        ========================== */

        @media (max-width: 700px) {

            .header {
                padding: 18px 20px;
            }

            .rt-container {
                grid-template-columns: 1fr;
            }

            .container {
                margin-top: 30px;
            }

        }

    </style>

</head>

<body>


<!-- =========================
     HEADER
========================== -->

<div class="header">

    <div class="logo">

        <h1>BMW</h1>

        <p>
            Bina Manunggal Warga
        </p>

    </div>

</div>


<!-- =========================
     CONTENT
========================== -->

<div class="container">


    <div class="title">

        <h2>
            Data BMW
        </h2>

        <p>
            Pilih RT untuk melihat dan mengelola data warga.
        </p>

    </div>


    <!-- RT -->

    <div class="rt-container">


        <!-- RT 10 -->

        <div class="rt-card">

            <div class="rt-icon">
                🏘️
            </div>

            <h3>
                RT 10
            </h3>
```
