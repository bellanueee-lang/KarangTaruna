<?php

session_start();

/* ==========================================
   CEK LOGIN
========================================== */

if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}


/* ==========================================
   KONEKSI DATABASE
========================================== */

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "db_bmw"
);

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}


/* ==========================================
   HAPUS DATA
========================================== */

if (isset($_GET["hapus"])) {

    $id = intval($_GET["hapus"]);

    $stmt = $conn->prepare(
        "DELETE FROM warga WHERE id = ?"
    );

    $stmt->bind_param("i", $id);

    $stmt->execute();

    header("Location: warga.php");
    exit;
}


/* ==========================================
   TAMBAH DATA
========================================== */

if (isset($_POST["tambah"])) {

    $rt_id   = intval($_POST["rt_id"]);
    $tanggal = $_POST["tanggal"];
    $nama    = trim($_POST["nama"]);
    $status  = $_POST["status"];

    $stmt = $conn->prepare(
        "INSERT INTO warga
        (rt_id, tanggal, nama, status)
        VALUES (?, ?, ?, ?)"
    );

    $stmt->bind_param(
        "isss",
        $rt_id,
        $tanggal,
        $nama,
        $status
    );

    $stmt->execute();

    header("Location: warga.php");
    exit;
}


/* ==========================================
   EDIT DATA
========================================== */

if (isset($_POST["edit"])) {

    $id      = intval($_POST["id"]);
    $rt_id   = intval($_POST["rt_id"]);
    $tanggal = $_POST["tanggal"];
    $nama    = trim($_POST["nama"]);
    $status  = $_POST["status"];

    $stmt = $conn->prepare(
        "UPDATE warga
         SET rt_id = ?,
             tanggal = ?,
             nama = ?,
             status = ?
         WHERE id = ?"
    );

    $stmt->bind_param(
        "isssi",
        $rt_id,
        $tanggal,
        $nama,
        $status,
        $id
    );

    $stmt->execute();

    header("Location: warga.php");
    exit;
}


/* ==========================================
   DATA UNTUK EDIT
========================================== */

$dataEdit = null;

if (isset($_GET["edit"])) {

    $id = intval($_GET["edit"]);

    $stmt = $conn->prepare(
        "SELECT * FROM warga WHERE id = ?"
    );

    $stmt->bind_param("i", $id);

    $stmt->execute();

    $resultEdit = $stmt->get_result();

    $dataEdit = $resultEdit->fetch_assoc();
}


/* ==========================================
   PENCARIAN
========================================== */

$cari = "";

if (isset($_GET["cari"])) {
    $cari = trim($_GET["cari"]);
}


/* ==========================================
   AMBIL DATA WARGA
========================================== */

if ($cari != "") {

    $stmt = $conn->prepare(
        "SELECT warga.*, rt.nama_rt
         FROM warga
         LEFT JOIN rt ON warga.rt_id = rt.id
         WHERE warga.nama LIKE ?
         OR rt.nama_rt LIKE ?
         OR warga.status LIKE ?
         ORDER BY warga.id DESC"
    );

    $keyword = "%" . $cari . "%";

    $stmt->bind_param(
        "sss",
        $keyword,
        $keyword,
        $keyword
    );

    $stmt->execute();

    $dataWarga = $stmt->get_result();

} else {

    $dataWarga = $conn->query(
        "SELECT warga.*, rt.nama_rt
         FROM warga
         LEFT JOIN rt ON warga.rt_id = rt.id
         ORDER BY warga.id DESC"
    );
}


/* ==========================================
   DATA RT
========================================== */

$dataRT = $conn->query(
    "SELECT * FROM rt ORDER BY id ASC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Data Warga - Karang Taruna BMW</title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }


        body {
            background: #f3f8f9;
            color: #333;
        }


        /* ==========================================
           SIDEBAR
        ========================================== */

        .sidebar {

            position: fixed;

            left: 0;
            top: 0;

            width: 250px;
            height: 100vh;

            background: #087f8c;

            color: white;

            padding: 25px 18px;
        }


        .brand {

            text-align: center;

            padding-bottom: 25px;

            border-bottom:
                1px solid
                rgba(255,255,255,0.2);
        }


        .brand h2 {
            font-size: 21px;
            margin-bottom: 5px;
        }


        .brand p {
            font-size: 12px;
            opacity: .85;
        }


        .menu {
            margin-top: 25px;
        }


        .menu a {

            display: flex;

            align-items: center;

            gap: 12px;

            color: white;

            text-decoration: none;

            padding: 13px 15px;

            margin-bottom: 7px;

            border-radius: 10px;

            font-size: 14px;
        }


        .menu a:hover,
        .menu a.active {

            background:
                rgba(255,255,255,.18);
        }


        .menu-icon {
            width: 25px;
            text-align: center;
            font-size: 18px;
        }


        .logout {

            position: absolute;

            bottom: 25px;

            left: 18px;
            right: 18px;

            background: white;

            color: #087f8c !important;

            justify-content: center;

            font-weight: bold;
        }


        /* ==========================================
           MAIN
        ========================================== */

        .main {

            margin-left: 250px;

            padding: 30px;
        }


        .topbar {

            background: white;

            padding: 22px 25px;

            border-radius: 15px;

            margin-bottom: 25px;

            box-shadow:
                0 4px 15px
                rgba(0,0,0,.05);

            display: flex;

            justify-content: space-between;

            align-items: center;
        }


        .topbar h1 {

            color: #087f8c;

            font-size: 25px;
        }


        .topbar p {

            color: #777;

            font-size: 13px;

            margin-top: 5px;
        }


        .user {

            text-align: right;
        }


        .user strong {
            color: #087f8c;
        }


        /* ==========================================
           FORM
        ========================================== */

        .box {

            background: white;

            padding: 25px;

            border-radius: 15px;

            margin-bottom: 25px;

            box-shadow:
                0 4px 15px
                rgba(0,0,0,.05);
        }


        .box h2 {

            color: #087f8c;

            font-size: 19px;

            margin-bottom: 20px;
        }


        .form-grid {

            display: grid;

            grid-template-columns:
                repeat(2, 1fr);

            gap: 18px;
        }


        .form-group label {

            display: block;

            font-size: 13px;

            font-weight: bold;

            margin-bottom: 7px;
        }


        .form-group input,
        .form-group select {

            width: 100%;

            padding: 12px;

            border: 1px solid #ddd;

            border-radius: 9px;

            outline: none;
        }


        .form-group input:focus,
        .form-group select:focus {

            border-color: #087f8c;
        }


        .button {

            border: none;

            padding: 12px 20px;

            border-radius: 9px;

            cursor: pointer;

            font-weight: bold;

            margin-top: 18px;
        }


        .button-tambah {

            background: #087f8c;

            color: white;
        }


        .button-edit {

            background: #f0a500;

            color: white;
        }


        .button-batal {

            background: #ddd;

            color: #444;

            text-decoration: none;

            display: inline-block;
        }


        /* ==========================================
           SEARCH
        ========================================== */

        .search {

            display: flex;

            gap: 10px;

            margin-bottom: 20px;
        }


        .search input {

            flex: 1;

            padding: 12px 15px;

            border: 1px solid #ddd;

            border-radius: 9px;

            outline: none;
        }


        .search button {

            padding: 12px 20px;

            border: none;

            border-radius: 9px;

            background: #087f8c;

            color: white;

            font-weight: bold;

            cursor: pointer;
        }


        .search a {

            padding: 12px 20px;

            background: #ddd;

            color: #444;

            text-decoration: none;

            border-radius: 9px;
        }


        /* ==========================================
           TABLE
        ========================================== */

        .table-wrapper {

            overflow-x: auto;
        }


        table {

            width: 100%;

            border-collapse: collapse;
        }


        th {

            background: #087f8c;

            color: white;

            padding: 13px;

            text-align: left;

            font-size: 13px;
        }


        td {

            padding: 13px;

            border-bottom:
                1px solid #eee;

            font-size: 13px;
        }


        tr:hover td {

            background: #f5fbfc;
        }


        .badge {

            padding: 6px 10px;

            border-radius: 20px;

            font-size: 11px;

            font-weight: bold;

            background: #dff6e5;

            color: #16833a;
        }


        .aksi {

            display: flex;

            gap: 7px;
        }


        .btn-edit {

            background: #f0a500;

            color: white;

            padding: 7px 11px;

            border-radius: 7px;

            text-decoration: none;

            font-size: 12px;
        }


        .btn-hapus {

            background: #dc3545;

            color: white;

            padding: 7px 11px;

            border-radius: 7px;

            text-decoration: none;

            font-size: 12px;
        }


        /* ==========================================
           RESPONSIVE
        ========================================== */

        @media(max-width: 800px) {

            .sidebar {
                width: 70px;
                padding: 20px 10px;
            }

            .brand h2,
            .brand p,
            .menu a span:not(.menu-icon) {
                display: none;
            }

            .menu a {
                justify-content: center;
            }

            .logout span:not(.menu-icon) {
                display: none;
            }

            .main {
                margin-left: 70px;
                padding: 20px;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .topbar {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

        }

    </style>

</head>


<body>


<!-- ==========================================
     SIDEBAR
========================================== -->

<aside class="sidebar">

    <div class="brand">

        <h2>Karang Taruna BMW</h2>

        <p>Bina Manunggal Warga</p>

    </div>


    <nav class="menu">

        <a href="dashboard.php">

            <span class="menu-icon">🏠</span>

            <span>Dashboard</span>

        </a>


        <a
            href="warga.php"
            class="active"
        >

            <span class="menu-icon">👥</span>

            <span>Data Warga</span>

        </a>


        <a href="#">

            <span class="menu-icon">👤</span>

            <span>Pengurus</span>

        </a>


        <a href="#">

            <span class="menu-icon">📅</span>

            <span>Kegiatan</span>

        </a>


        <a href="#">

            <span class="menu-icon">📝</span>

            <span>Notulen</span>

        </a>


        <a href="#">

            <span class="menu-icon">🏘️</span>

            <span>Data RT</span>

        </a>


        <a href="#">

            <span class="menu-icon">💰</span>

            <span>Transaksi</span>

        </a>

    </nav>


    <a
        href="logout.php"
        class="menu logout"
    >

        <span class="menu-icon">🚪</span>

        <span>Keluar</span>

    </a>

</aside>



<!-- ==========================================
     MAIN
========================================== -->

<main class="main">


    <!-- TOPBAR -->

    <div class="topbar">

        <div>

            <h1>
                Data Warga
            </h1>

            <p>
                Kelola data warga Karang Taruna BMW
            </p>

        </div>


        <div class="user">

            Login sebagai:

            <strong>
                <?= htmlspecialchars($_SESSION["nama"] ?? "Admin") ?>
            </strong>

        </div>

    </div>



    <!-- ==========================================
         FORM TAMBAH / EDIT
    ========================================== -->

    <div class="box">

        <?php if ($dataEdit) { ?>

            <h2>
                ✏️ Edit Data Warga
            </h2>

            <form method="POST">

                <input
                    type="hidden"
                    name="id"
                    value="<?= $dataEdit["id"] ?>"
                >


                <div class="form-grid">


                    <div class="form-group">

                        <label>
                            RT
                        </label>

                        <select
                            name="rt_id"
                            required
                        >

                            <?php

                            $dataRT->data_seek(0);

                            while ($rt = $dataRT->fetch_assoc()) {

                            ?>

                                <option
                                    value="<?= $rt["id"] ?>"
                                    <?= ($rt["id"] == $dataEdit["rt_id"]) ? "selected" : "" ?>
                                >

                                    <?= htmlspecialchars($rt["nama_rt"]) ?>

                                </option>

                            <?php } ?>

                        </select>

                    </div>


                    <div class="form-group">

                        <label>
                            Tanggal
                        </label>

                        <input
                            type="date"
                            name="tanggal"
                            value="<?= $dataEdit["tanggal"] ?>"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            Nama Warga
                        </label>

                        <input
                            type="text"
                            name="nama"
                            value="<?= htmlspecialchars($dataEdit["nama"]) ?>"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            Status
                        </label>

                        <select
                            name="status"
                            required
                        >

                            <option
                                value="Aktif"
                                <?= ($dataEdit["status"] == "Aktif") ? "selected" : "" ?>
                            >
                                Aktif
                            </option>

                            <option
                                value="Tidak Aktif"
                                <?= ($dataEdit["status"] == "Tidak Aktif") ? "selected" : "" ?>
                            >
                                Tidak Aktif
                            </option>

                        </select>

                    </div>


                </div>


                <button
                    type="submit"
                    name="edit"
                    class="button button-edit"
                >
                    💾 Simpan Perubahan
                </button>


                <a
                    href="warga.php"
                    class="button button-batal"
                >
                    Batal
                </a>

            </form>


        <?php } else { ?>


            <h2>
                ➕ Tambah Data Warga
            </h2>


            <form method="POST">

                <div class="form-grid">


                    <div class="form-group">

                        <label>
                            RT
                        </label>

                        <select
                            name="rt_id"
                            required
                        >

                            <option value="">
                                -- Pilih RT --
                            </option>

                            <?php

                            $dataRT->data_seek(0);

                            while ($rt = $dataRT->fetch_assoc()) {

                            ?>

                                <option value="<?= $rt["id"] ?>">

                                    <?= htmlspecialchars($rt["nama_rt"]) ?>

                                </option>

                            <?php } ?>

                        </select>

                    </div>


                    <div class="form-group">

                        <label>
                            Tanggal
                        </label>

                        <input
                            type="date"
                            name="tanggal"
                            value="<?= date("Y-m-d") ?>"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            Nama Warga
                        </label>

                        <input
                            type="text"
                            name="nama"
                            placeholder="Masukkan nama warga"
                            required
                        >

                    </div>


                    <div class="form-group">

                        <label>
                            Status
                        </label>

                        <select
                            name="status"
                            required
                        >

                            <option value="">
                                -- Pilih Status --
                            </option>

                            <option value="Aktif">
                                Aktif
                            </option>

                            <option value="Tidak Aktif">
                                Tidak Aktif
                            </option>

                        </select>

                    </div>


                </div>


                <button
                    type="submit"
                    name="tambah"
                    class="button button-tambah"
                >
                    ➕ Tambah Warga
                </button>

            </form>


        <?php } ?>

    </div>



    <!-- ==========================================
         DATA WARGA
    ========================================== -->

    <div class="box">

        <h2>
            📋 Daftar Warga
        </h2>


        <!-- SEARCH -->

        <form
            method="GET"
            class="search"
        >

            <input
                type="text"
                name="cari"
                placeholder="Cari nama, RT, atau status..."
                value="<?= htmlspecialchars($cari) ?>"
            >


            <button type="submit">
                🔍 Cari
            </button>


            <?php if ($cari != "") { ?>

                <a href="warga.php">
                    Reset
                </a>

            <?php } ?>

        </form>


        <!-- TABLE -->

        <div class="table-wrapper">

            <table>

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Nama</th>

                        <th>RT</th>

                        <th>Tanggal</th>

                        <th>Status</th>

                        <th>Aksi</th>

                    </tr>

                </thead>


                <tbody>

                <?php

                $no = 1;

                if ($dataWarga && $dataWarga->num_rows > 0) {

                    while ($row = $dataWarga->fetch_assoc()) {

                ?>

                    <tr>

                        <td>
                            <?= $no++ ?>
                        </td>


                        <td>
                            <strong>
                                <?= htmlspecialchars($row["nama"]) ?>
                            </strong>
                        </td>


                        <td>
                            <?= htmlspecialchars($row["nama_rt"]) ?>
                        </td>


                        <td>
                            <?= date(
                                "d-m-Y",
                                strtotime($row["tanggal"])
                            ) ?>
                        </td>


                        <td>

                            <span class="badge">

                                <?= htmlspecialchars($row["status"]) ?>

                            </span>

                        </td>


                        <td>

                            <div class="aksi">


                                <!-- EDIT -->

                                <a
                                    href="warga.php?edit=<?= $row["id"] ?>"
                                    class="btn-edit"
                                >
                                    ✏️ Edit
                                </a>


                                <!-- HAPUS -->

                                <a
                                    href="warga.php?hapus=<?= $row["id"] ?>"
                                    class="btn-hapus"
                                    onclick="return confirm('Yakin ingin menghapus data <?= htmlspecialchars($row["nama"]) ?>?')"
                                >
                                    🗑️ Hapus
                                </a>


                            </div>

                        </td>

                    </tr>


                <?php

                    }

                } else {

                ?>

                    <tr>

                        <td
                            colspan="6"
                            style="text-align:center; padding:30px;"
                        >

                            Data warga belum ada.

                        </td>

                    </tr>

                <?php } ?>

                </tbody>

            </table>

        </div>

    </div>


</main>


</body>

</html>