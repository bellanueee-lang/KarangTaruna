<?php
session_start();

if (!isset($_SESSION["login"])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "db_bmw");

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

function jumlahData($conn, $table)
{
    $query = "SELECT COUNT(*) AS total FROM `$table`";
    $hasil = $conn->query($query);

    if ($hasil) {
        $data = $hasil->fetch_assoc();
        return $data["total"];
    }

    return 0;
}

$totalKarangTaruna = jumlahData($conn, "warga");
$totalPengurus     = jumlahData($conn, "pengurus");
$totalKegiatan     = jumlahData($conn, "kegiatan");
$totalNotulen      = jumlahData($conn, "notulen");
$totalRT           = jumlahData($conn, "rt");
$totalTransaksi    = jumlahData($conn, "transaksi");

$namaUser = $_SESSION["nama"] ?? "Administrator BMW";
$username = $_SESSION["username"] ?? "admin";
?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Dashboard - Karang Taruna BMW</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, Helvetica, sans-serif;
}

body {
    background: #f3f8f9;
    color: #333;
}


/* SIDEBAR */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 250px;
    height: 100vh;
    background: #087f8c;
    color: white;
    padding: 25px 18px;
    z-index: 1000;
}

.brand {
    text-align: center;
    padding-bottom: 25px;
    border-bottom: 1px solid rgba(255,255,255,0.25);
}

.brand h2 {
    font-size: 21px;
    margin-bottom: 5px;
}

.brand p {
    font-size: 12px;
    opacity: .9;
}

.menu {
    margin-top: 25px;
}

.menu a {
    display: flex;
    align-items: center;
    gap: 12px;
    color: white;
    text-decoration: none;
    padding: 13px 15px;
    margin-bottom: 7px;
    border-radius: 10px;
    font-size: 14px;
    transition: .2s;
}

.menu a:hover,
.menu a.active {
    background: rgba(255,255,255,.18);
}

.menu-icon {
    width: 25px;
    text-align: center;
    font-size: 18px;
}

.logout {
    position: absolute;
    bottom: 25px;
    left: 18px;
    right: 18px;
    background: white;
    color: #087f8c !important;
    justify-content: center;
    font-weight: bold;
}


/* MAIN */

.main {
    margin-left: 250px;
    padding: 30px;
}

.topbar {
    background: white;
    padding: 22px 25px;
    border-radius: 15px;
    margin-bottom: 28px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.topbar h1 {
    color: #087f8c;
    font-size: 27px;
    margin-bottom: 5px;
}

.topbar p {
    color: #777;
    font-size: 14px;
}

.user {
    text-align: right;
}

.user strong {
    display: block;
    color: #222;
    font-size: 16px;
}

.user span {
    color: #087f8c;
    font-size: 13px;
}


/* JUDUL */

.section-title {
    margin-bottom: 18px;
}

.section-title h2 {
    font-size: 21px;
}

.section-title p {
    color: #777;
    font-size: 13px;
}


/* CARDS */

.cards {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 30px;
}

.card {
    background: white;
    border-radius: 15px;
    padding: 22px;
    display: flex;
    align-items: center;
    gap: 18px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
    transition: .2s;
}

.card:hover {
    transform: translateY(-3px);
}

.card-icon {
    width: 55px;
    height: 55px;
    border-radius: 13px;
    background: #e0f5f7;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 27px;
}

.card-info .number {
    font-size: 27px;
    font-weight: bold;
    color: #087f8c;
    margin-bottom: 4px;
}

.card-info .label {
    font-size: 13px;
    color: #777;
}


/* BOTTOM */

.bottom {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
}

.content-box {
    background: white;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 5px 20px rgba(0,0,0,.05);
}

.content-box h2 {
    color: #087f8c;
    font-size: 19px;
    margin-bottom: 15px;
}

.content-box p {
    color: #666;
    font-size: 14px;
    line-height: 1.8;
}


/* MENU CEPAT */

.quick-menu {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.quick-menu a {
    display: block;
    text-decoration: none;
    background: #eef9fa;
    color: #087f8c;
    padding: 13px 15px;
    border-radius: 9px;
    font-size: 13px;
    font-weight: bold;
}

.quick-menu a:hover {
    background: #087f8c;
    color: white;
}


/* RESPONSIVE */

@media (max-width: 1000px) {

    .cards {
        grid-template-columns: repeat(2,1fr);
    }

    .bottom {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 750px) {

    .sidebar {
        width: 70px;
        padding: 20px 10px;
    }

    .brand h2,
    .brand p {
        display: none;
    }

    .menu a {
        justify-content: center;
    }

    .menu a span:not(.menu-icon) {
        display: none;
    }

    .logout span:not(.menu-icon) {
        display: none;
    }

    .main {
        margin-left: 70px;
        padding: 20px;
    }

    .topbar {
        flex-direction: column;
        align-items: flex-start;
        gap: 15px;
    }

    .user {
        text-align: left;
    }

    .cards {
        grid-template-columns: 1fr;
    }
}

</style>

</head>

<body>


<!-- SIDEBAR -->

<aside class="sidebar">

    <div class="brand">

        <h2>Karang Taruna BMW</h2>

        <p>Bina Manunggal Warga</p>

    </div>


    <nav class="menu">

        <a href="dashboard.php" class="active">
            <span class="menu-icon">🏠</span>
            <span>Dashboard</span>
        </a>


        <a href="warga.php">
            <span class="menu-icon">👥</span>
            <span>Karang Taruna</span>
        </a>


        <a href="pengurus.php">
            <span class="menu-icon">👤</span>
            <span>Pengurus</span>
        </a>


        <a href="kegiatan.php">
            <span class="menu-icon">📅</span>
            <span>Kegiatan</span>
        </a>


        <a href="notulen.php">
            <span class="menu-icon">📝</span>
            <span>Notulen</span>
        </a>


        <a href="rt.php">
            <span class="menu-icon">🏘️</span>
            <span>Data RT</span>
        </a>


        <a href="transaksi.php">
            <span class="menu-icon">💰</span>
            <span>Transaksi</span>
        </a>

    </nav>


    <a href="logout.php" class="menu logout">

        <span class="menu-icon">🚪</span>

        <span>Keluar</span>

    </a>

</aside>


<!-- MAIN -->

<main class="main">


    <div class="topbar">

        <div>

            <h1>Dashboard</h1>

            <p>
                Selamat datang di Sistem Informasi
                Karang Taruna BMW
            </p>

        </div>


        <div class="user">

            <strong>
                <?= htmlspecialchars($namaUser) ?>
            </strong>

            <span>
                @<?= htmlspecialchars($username) ?>
            </span>

        </div>

    </div>


    <div class="section-title">

        <h2>Ringkasan Data</h2>

        <p>
            Informasi data yang tersimpan dalam sistem.
        </p>

    </div>


    <div class="cards">


        <div class="card">

            <div class="card-icon">👥</div>

            <div class="card-info">

                <div class="number">
                    <?= $totalKarangTaruna ?>
                </div>

                <div class="label">
                    Total Karang Taruna
                </div>

            </div>

        </div>


        <div class="card">

            <div class="card-icon">👤</div>

            <div class="card-info">

                <div class="number">
                    <?= $totalPengurus ?>
                </div>

                <div class="label">
                    Pengurus
                </div>

            </div>

        </div>


        <div class="card">

            <div class="card-icon">📅</div>

            <div class="card-info">

                <div class="number">
                    <?= $totalKegiatan ?>
                </div>

                <div class="label">
                    Kegiatan
                </div>

            </div>

        </div>


        <div class="card">

            <div class="card-icon">📝</div>

            <div class="card-info">

                <div class="number">
                    <?= $totalNotulen ?>
                </div>

                <div class="label">
                    Notulen
                </div>

            </div>

        </div>


        <div class="card">

            <div class="card-icon">🏘️</div>

            <div class="card-info">

                <div class="number">
                    <?= $totalRT ?>
                </div>

                <div class="label">
                    Data RT
                </div>

            </div>

        </div>


        <div class="card">

            <div class="card-icon">💰</div>

            <div class="card-info">

                <div class="number">
                    <?= $totalTransaksi ?>
                </div>

                <div class="label">
                    Transaksi
                </div>

            </div>

        </div>


    </div>


    <div class="bottom">


        <div class="content-box">

            <h2>Tentang Sistem</h2>

            <p>

                Sistem Informasi Karang Taruna
                Bina Manunggal Warga dibuat untuk
                membantu pengelolaan data Karang Taruna,
                pengurus, kegiatan, notulen,
                RT, dan transaksi secara lebih
                mudah dan terorganisasi.

            </p>

        </div>


        <div class="content-box">

            <h2>Menu Cepat</h2>


            <div class="quick-menu">

                <a href="warga.php">
                    👥 &nbsp; Kelola Karang Taruna
                </a>

                <a href="pengurus.php">
                    👤 &nbsp; Kelola Pengurus
                </a>

                <a href="kegiatan.php">
                    📅 &nbsp; Kelola Kegiatan
                </a>

                <a href="notulen.php">
                    📝 &nbsp; Kelola Notulen
                </a>

                <a href="rt.php">
                    🏘️ &nbsp; Kelola Data RT
                </a>

                <a href="transaksi.php">
                    💰 &nbsp; Kelola Transaksi
                </a>

            </div>

        </div>


    </div>


</main>

</body>

</html>