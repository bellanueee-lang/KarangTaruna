<?php

session_start();

/* ============================
   KONEKSI DATABASE
============================ */

$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_bmw";

$conn = new mysqli($host, $user, $pass, $db);


/* Cek koneksi */

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}


/* ============================
   PROSES LOGIN
============================ */

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST["username"];
    $password = $_POST["password"];


    /* Cari username di tabel users */

    $sql = "SELECT * FROM users WHERE username = ?";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $username);

    $stmt->execute();

    $result = $stmt->get_result();


    /* Jika username ditemukan */

    if ($result->num_rows == 1) {

        $data = $result->fetch_assoc();


        /* Cek password */

        if ($password == $data["password"]) {

            $_SESSION["login"] = true;

            $_SESSION["id"] = $data["id"];

            $_SESSION["username"] = $data["username"];

            $_SESSION["nama"] = $data["nama"];


            /* Masuk ke dashboard */

            header("Location: dashboard.php");

            exit;

        } else {

            $error = "Password salah!";

        }

    } else {

        $error = "Username tidak ditemukan!";

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Login - Karang Taruna BMW</title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }


        body {

            min-height: 100vh;

            display: flex;

            justify-content: center;

            align-items: center;

            background:
                linear-gradient(
                    135deg,
                    #087f8c,
                    #0aa6b4
                );
        }


        .login-container {

            width: 420px;

            max-width: 90%;

            background: white;

            padding: 45px 40px;

            border-radius: 20px;

            box-shadow:
                0 15px 40px
                rgba(0,0,0,0.2);

            text-align: center;
        }


        h1 {

            color: #087f8c;

            font-size: 28px;

            margin-bottom: 8px;
        }


        .subtitle {

            color: #777;

            font-size: 14px;

            margin-bottom: 35px;
        }


        .error {

            background: #ffe5e5;

            color: #d60000;

            padding: 12px;

            border-radius: 8px;

            margin-bottom: 20px;

            font-size: 14px;
        }


        .form-group {

            text-align: left;

            margin-bottom: 20px;
        }


        .form-group label {

            display: block;

            color: #444;

            font-weight: bold;

            margin-bottom: 8px;

            font-size: 14px;
        }


        .form-group input {

            width: 100%;

            padding: 13px 15px;

            border: 1px solid #ddd;

            border-radius: 10px;

            outline: none;

            font-size: 15px;
        }


        .form-group input:focus {

            border-color: #087f8c;

            box-shadow:
                0 0 0 3px
                rgba(8,127,140,0.1);
        }


        .login-button {

            width: 100%;

            border: none;

            padding: 14px;

            border-radius: 25px;

            background: #087f8c;

            color: white;

            font-size: 16px;

            font-weight: bold;

            cursor: pointer;
        }


        .login-button:hover {

            background: #066b76;
        }


        .back {

            display: inline-block;

            margin-top: 25px;

            color: #087f8c;

            text-decoration: none;

            font-size: 14px;
        }


        .footer {

            margin-top: 25px;

            color: #999;

            font-size: 12px;
        }

    </style>

</head>


<body>


    <div class="login-container">


        <h1>
            Login Sistem
        </h1>


        <p class="subtitle">
            Karang Taruna Bina Manunggal Warga
        </p>


        <?php if ($error != "") { ?>

            <div class="error">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php } ?>


        <form method="POST">


            <div class="form-group">

                <label>
                    Username
                </label>

                <input
                    type="text"
                    name="username"
                    placeholder="Masukkan username"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    placeholder="Masukkan password"
                    required
                >

            </div>


            <button
                type="submit"
                class="login-button"
            >
                MASUK
            </button>


        </form>


        <a
            href="index.php"
            class="back"
        >
            ← Kembali ke halaman utama
        </a>


        <div class="footer">
            © 2026 Karang Taruna BMW
        </div>


    </div>


</body>

</html>