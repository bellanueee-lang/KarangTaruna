```php
<?php

include "koneksi.php";

// ===============================
// AMBIL RT ID
// ===============================

if (isset($_GET['rt_id'])) {

    $rt_id = (int) $_GET['rt_id'];

} elseif (isset($_POST['rt_id'])) {

    $rt_id = (int) $_POST['rt_id'];

} else {

    die("RT belum dipilih.");

}


// ===============================
// CEK DATA RT
// ===============================

$query_rt = mysqli_query(
    $koneksi,
    "SELECT * FROM rt WHERE id = $rt_id"
);

if (!$query_rt) {

    die(
        "Terjadi kesalahan saat mengambil data RT: "
        . mysqli_error($koneksi)
    );

}

if (mysqli_num_rows($query_rt) == 0) {

    die("RT tidak ditemukan.");

}

$rt = mysqli_fetch_assoc($query_rt);


// ===============================
// PROSES SIMPAN DATA
// ===============================

if (isset($_POST['simpan'])) {

    $tanggal = mysqli_real_escape_string(
        $koneksi,
        $_POST['tanggal']
    );

    $nama = mysqli_real_escape_string(
        $koneksi,
        $_POST['nama']
    );

    $status = mysqli_real_escape_string(
        $koneksi,
        $_POST['status']
    );


    // Query INSERT
    $sql = "INSERT INTO warga
            (rt_id, tanggal, nama, status)
            VALUES
            ('$rt_id', '$tanggal', '$nama', '$status')";


    $simpan = mysqli_query($koneksi, $sql);


    // Jika gagal
    if (!$simpan) {

        die(
            "Data gagal disimpan: "
            . mysqli_error($koneksi)
        );

    }


    // Jika berhasil
    header(
        "Location: data_bmw.php?rt_id=" . $rt_id
    );

    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah Data BMW</title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }


        body {
            background: #f8f1e7;
            color: #4e342e;
        }


        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
        }


        .card {
            background: white;
            padding: 35px;
            border-radius: 22px;
            box-shadow: 0 10px 30px rgba(78, 52, 46, 0.12);
        }


        h1 {
            color: #5d4037;
            margin-bottom: 8px;
        }


        .subtitle {
            color: #8d6e63;
            margin-bottom: 30px;
        }


        .form-group {
            margin-bottom: 20px;
        }


        label {
            display: block;
            margin-bottom: 8px;
            color: #5d4037;
            font-weight: bold;
        }


        input,
        select {

            width: 100%;

            padding: 13px;

            border: 1px solid #d7ccc8;

            border-radius: 9px;

            font-size: 15px;

            outline: none;

        }


        input:focus,
        select:focus {

            border-color: #6d4c41;

        }


        .buttons {

            display: flex;

            gap: 10px;

            margin-top: 25px;

        }


        .btn,
        button {

            padding: 12px 20px;

            border-radius: 9px;

            border: none;

            text-decoration: none;

            font-weight: bold;

            cursor: pointer;

            font-size: 14px;

        }


        .simpan {

            background: #6d4c41;

            color: white;

        }


        .simpan:hover {

            background: #4e342e;

        }


        .batal {

            background: #eee0d5;

            color: #5d4037;

        }


        .batal:hover {

            background: #e0d0c4;

        }

    </style>

</head>


<body>


<div class="container">

    <div class="card">


        <h1>
            Tambah Data BMW
        </h1>


        <p class="subtitle">

            Tambah data warga
            <strong>
                <?= htmlspecialchars($rt['nama_rt']) ?>
            </strong>

        </p>


        <form method="POST">


            <!--
                Menyimpan ID RT
                agar data masuk ke RT yang benar
            -->

            <input
                type="hidden"
                name="rt_id"
                value="<?= $rt_id ?>"
            >


            <!-- =========================
                 TANGGAL
            ========================== -->

            <div class="form-group">

                <label>
                    Tanggal
                </label>

                <input
                    type="date"
                    name="tanggal"
                    required
                >

            </div>


            <!-- =========================
                 NAMA
            ========================== -->

            <div class="form-group">

                <label>
                    Nama Lengkap
                </label>

                <input
                    type="text"
                    name="nama"
                    placeholder="Masukkan nama lengkap"
                    required
                >

            </div>


            <!-- =========================
                 STATUS
            ========================== -->

            <div class="form-group">

                <label>
                    Status
                </label>

                <select
                    name="status"
                    required
                >

                    <option value="">
                        -- Pilih Status --
                    </option>

                    <option value="Aktif">
                        Aktif
                    </option>

                    <option value="Tidak Aktif">
                        Tidak Aktif
                    </option>

                </select>

            </div>


            <!-- =========================
                 TOMBOL
            ========================== -->

            <div class="buttons">

                <button
                    type="submit"
                    name="simpan"
                    class="simpan"
                >
                    Simpan Data
                </button>


                <a
                    href="data_bmw.php?rt_id=<?= $rt_id ?>"
                    class="btn batal"
                >
                    Batal
                </a>

            </div>


        </form>


    </div>

</div>


</body>

</html>
```
