```php
<?php

include "koneksi.php";

// Password baru
$password = password_hash("password", PASSWORD_DEFAULT);

// Update password admin
$sql = "UPDATE users
        SET password = '$password'
        WHERE username = 'admin'";

if (mysqli_query($koneksi, $sql)) {

    echo "<h2>Password admin berhasil diubah!</h2>";
    echo "<p>Username: <b>admin</b></p>";
    echo "<p>Password: <b>password</b></p>";

} else {

    echo "Gagal mengubah password: "
        . mysqli_error($koneksi);

}

?>
```
