<?php

session_start();

// ===============================
// CEK LOGIN
// ===============================

if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {

    header("Location: login.php");

    exit;
}


// ===============================
// KONEKSI DATABASE
// ===============================

include "koneksi.php";


// ===============================
// AMBIL RT ID
// ===============================

$rt_id = isset($_GET['rt_id'])
    ? (int) $_GET['rt_id']
    : 0;


// ===============================
// CEK RT
// ===============================

$query_rt = mysqli_query(
    $koneksi,
    "SELECT * FROM rt WHERE id = $rt_id"
);


if (mysqli_num_rows($query_rt) == 0) {

    die("RT tidak ditemukan.");

}


$rt = mysqli_fetch_assoc($query_rt);


// ===============================
// AMBIL DATA WARGA
// ===============================

$query_warga = mysqli_query(
    $koneksi,
    "SELECT * FROM warga
     WHERE rt_id = $rt_id
     ORDER BY tanggal DESC"
);


?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>
        Data BMW - <?= htmlspecialchars($rt['nama_rt']) ?>
    </title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }


        body {
            background: #f8f1e7;
            color: #4e342e;
        }


        /* =========================
           HEADER
        ========================== */

        .header {

            background: #5d4037;

            color: white;

            padding: 20px 40px;

            display: flex;

            justify-content: space-between;

            align-items: center;

        }


        .logo h1 {

            font-size: 28px;

            letter-spacing: 2px;

        }


        .logo p {

            font-size: 12px;

            opacity: 0.8;

            margin-top: 4px;

        }


        /* =========================
           CONTAINER
        ========================== */

        .container {

            max-width: 1100px;

            margin: 40px auto;

            padding: 0 25px;

        }


        .top {

            display: flex;

            justify-content: space-between;

            align-items: center;

            gap: 20px;

            margin-bottom: 25px;

        }


        .title h2 {

            color: #5d4037;

            font-size: 29px;

            margin-bottom: 7px;

        }


        .title p {

            color: #8d6e63;

        }


        /* =========================
           BUTTON
        ========================== */

        .buttons {

            display: flex;

            gap: 10px;

            flex-wrap: wrap;

        }


        .btn {

            display: inline-block;

            padding: 11px 18px;

            border-radius: 10px;

            text-decoration: none;

            font-weight: bold;

            font-size: 14px;

        }


        .btn-back {

            background: white;

            color: #6d4c41;

            border: 1px solid #d7ccc8;

        }


        .btn-back:hover {

            background: #6d4c41;

            color: white;

        }


        .btn-add {

            background: #6d4c41;

            color: white;

        }


        .btn-add:hover {

            background: #4e342e;

        }


        /* =========================
           TABLE
        ========================== */

        .table-card {

            background: white;

            border-radius: 18px;

            overflow: hidden;

            box-shadow:
                0 8px 25px
                rgba(78,52,46,0.10);

        }


        table {

            width: 100%;

            border-collapse: collapse;

        }


        th {

            background: #6d4c41;

            color: white;

            padding: 15px;

            text-align: left;

            font-size: 14px;

        }


        td {

            padding: 14px 15px;

            border-bottom: 1px solid #eee0d5;

            font-size: 14px;

        }


        tr:last-child td {

            border-bottom: none;

        }


        tr:hover td {

            background: #fcf8f3;

        }


        /* =========================
           ACTION
        ========================== */

        .btn-edit {

            display: inline-block;

            padding: 7px 12px;

            background: #eee0d5;

            color: #5d4037;

            text-decoration: none;

            border-radius: 7px;

            font-size: 12px;

            font-weight: bold;

            margin-right: 5px;

        }


        .btn-delete {

            display: inline-block;

            padding: 7px 12px;

            background: #f8d7da;

            color: #842029;

            text-decoration: none;

            border-radius: 7px;

            font-size: 12px;

            font-weight: bold;

        }


        /* =========================
           EMPTY DATA
        ========================== */

        .empty {

            text-align: center;

            padding: 50px 20px;

            color: #8d6e63;

        }


        .empty-icon {

            font-size: 45px;

            margin-bottom: 15px;

        }


        /* =========================
           FOOTER
        ========================== */

        .footer {

            text-align: center;

            padding: 30px;

            color: #8d6e63;

            font-size: 13px;

        }


        /* =========================
           RESPONSIVE
        ========================== */

        @media (max-width: 750px) {

            .top {

                flex-direction: column;

                align-items: flex-start;

            }


            .table-card {

                overflow-x: auto;

            }


            table {

                min-width: 700px;

            }

        }

    </style>

</head>


<body>


<!-- =========================
     HEADER
========================== -->

<div class="header">

    <div class="logo">

        <h1>BMW</h1>

        <p>
            Bina Manunggal Warga
        </p>

    </div>

</div>


<!-- =========================
     CONTENT
========================== -->

<div class="container">


    <div class="top">


        <div class="title">

            <h2>
                Data <?= htmlspecialchars($rt['nama_rt']) ?>
            </h2>

            <p>
                Data warga Karang Taruna
                Bina Manunggal Warga
            </p>

        </div>


        <div class="buttons">

            <!-- KEMBALI KE DASHBOARD -->

            <a
                href="dashboard.php"
                class="btn btn-back"
            >
                ← Dashboard
            </a>


            <!-- KEMBALI PILIH RT -->

            <a
                href="tentang.php"
                class="btn btn-back"
            >
                Pilih RT
            </a>


            <!-- TAMBAH -->

            <a
                href="tambah_bmw.php?rt_id=<?= $rt_id ?>"
                class="btn btn-add"
            >
                + Tambah Data
            </a>

        </div>


    </div>


    <!-- =========================
         TABLE
    ========================== -->

    <div class="table-card">


        <?php if (mysqli_num_rows($query_warga) > 0): ?>


            <table>

                <thead>

                    <tr>

                        <th width="60">
                            No
                        </th>

                        <th>
                            Tanggal
                        </th>

                        <th>
                            Nama
                        </th>

                        <th>
                            Status
                        </th>

                        <th width="170">
                            Aksi
                        </th>

                    </tr>

                </thead>


                <tbody>


                    <?php

                    $no = 1;

                    while ($data = mysqli_fetch_assoc($query_warga)):

                    ?>


                        <tr>

                            <td>
                                <?= $no++ ?>
                            </td>


                            <td>

                                <?= date(
                                    'd-m-Y',
                                    strtotime($data['tanggal'])
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $data['nama']
                                ) ?>

                            </td>


                            <td>

                                <?= htmlspecialchars(
                                    $data['status']
                                ) ?>

                            </td>


                            <td>

                                <a
                                    href="edit_bmw.php?id=<?= $data['id'] ?>"
                                    class="btn-edit"
                                >
                                    Edit
                                </a>


                                <a
                                    href="hapus_bmw.php?id=<?= $data['id'] ?>&rt_id=<?= $rt_id ?>"
                                    class="btn-delete"
                                    onclick="return confirm('Yakin ingin menghapus data ini?')"
                                >
                                    Hapus
                                </a>

                            </td>

                        </tr>


                    <?php endwhile; ?>


                </tbody>

            </table>


        <?php else: ?>


            <div class="empty">

                <div class="empty-icon">
                    📋
                </div>

                <h3>
                    Belum Ada Data
                </h3>

                <p>
                    Belum ada data warga untuk
                    <?= htmlspecialchars($rt['nama_rt']) ?>.
                </p>

            </div>


        <?php endif; ?>


    </div>


</div>


<!-- =========================
     FOOTER
========================== -->

<div class="footer">

    BMW — Bina Manunggal Warga

</div>


</body>

</html>