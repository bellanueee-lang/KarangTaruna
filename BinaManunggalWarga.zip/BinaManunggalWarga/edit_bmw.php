```php
<?php

include "koneksi.php";

// ===============================
// AMBIL ID DATA
// ===============================

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;


// ===============================
// AMBIL DATA WARGA
// ===============================

$query = mysqli_query(
    $koneksi,
    "SELECT warga.*, rt.nama_rt
     FROM warga
     INNER JOIN rt ON warga.rt_id = rt.id
     WHERE warga.id = $id"
);

if (!$query) {
    die("Error mengambil data: " . mysqli_error($koneksi));
}

if (mysqli_num_rows($query) == 0) {
    die("Data tidak ditemukan.");
}

$data = mysqli_fetch_assoc($query);

$rt_id = $data['rt_id'];


// ===============================
// PROSES UPDATE
// ===============================

if (isset($_POST['update'])) {

    $tanggal = mysqli_real_escape_string(
        $koneksi,
        $_POST['tanggal']
    );

    $nama = mysqli_real_escape_string(
        $koneksi,
        $_POST['nama']
    );

    $status = mysqli_real_escape_string(
        $koneksi,
        $_POST['status']
    );


    $sql = "UPDATE warga SET
                tanggal = '$tanggal',
                nama = '$nama',
                status = '$status'
            WHERE id = $id";


    $update = mysqli_query($koneksi, $sql);


    if (!$update) {

        die(
            "Data gagal diperbarui: "
            . mysqli_error($koneksi)
        );

    }


    header(
        "Location: data_bmw.php?rt_id=" . $rt_id
    );

    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Data BMW</title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }


        body {
            background: #f8f1e7;
            color: #4e342e;
        }


        .container {
            max-width: 600px;
            margin: 60px auto;
            padding: 20px;
        }


        .card {

            background: white;

            padding: 35px;

            border-radius: 22px;

            box-shadow: 0 10px 30px rgba(78,52,46,0.12);

        }


        h1 {

            color: #5d4037;

            margin-bottom: 8px;

        }


        .subtitle {

            color: #8d6e63;

            margin-bottom: 30px;

        }


        .form-group {

            margin-bottom: 20px;

        }


        label {

            display: block;

            margin-bottom: 8px;

            color: #5d4037;

            font-weight: bold;

        }


        input,
        select {

            width: 100%;

            padding: 13px;

            border: 1px solid #d7ccc8;

            border-radius: 9px;

            font-size: 15px;

            outline: none;

        }


        input:focus,
        select:focus {

            border-color: #6d4c41;

        }


        .buttons {

            display: flex;

            gap: 10px;

            margin-top: 25px;

        }


        .btn {

            padding: 12px 20px;

            border-radius: 9px;

            border: none;

            text-decoration: none;

            font-weight: bold;

            cursor: pointer;

            font-size: 14px;

        }


        .update {

            background: #6d4c41;

            color: white;

        }


        .update:hover {

            background: #4e342e;

        }


        .batal {

            background: #eee0d5;

            color: #5d4037;

        }


        .batal:hover {

            background: #e0d0c4;

        }

    </style>

</head>


<body>


<div class="container">

    <div class="card">


        <h1>
            Edit Data BMW
        </h1>


        <p class="subtitle">

            Edit data warga
            <strong>
                <?= htmlspecialchars($data['nama_rt']) ?>
            </strong>

        </p>


        <form method="POST">


            <!-- TANGGAL -->

            <div class="form-group">

                <label>
                    Tanggal
                </label>

                <input
                    type="date"
                    name="tanggal"
                    value="<?= htmlspecialchars($data['tanggal']) ?>"
                    required
                >

            </div>


            <!-- NAMA -->

            <div class="form-group">

                <label>
                    Nama Lengkap
                </label>

                <input
                    type="text"
                    name="nama"
                    value="<?= htmlspecialchars($data['nama']) ?>"
                    placeholder="Masukkan nama lengkap"
                    required
                >

            </div>


            <!-- STATUS -->

            <div class="form-group">

                <label>
                    Status
                </label>

                <select
                    name="status"
                    required
                >

                    <option value="">
                        -- Pilih Status --
                    </option>


                    <option
                        value="Aktif"
                        <?= $data['status'] == 'Aktif' ? 'selected' : '' ?>
                    >
                        Aktif
                    </option>


                    <option
                        value="Tidak Aktif"
                        <?= $data['status'] == 'Tidak Aktif' ? 'selected' : '' ?>
                    >
                        Tidak Aktif
                    </option>

                </select>

            </div>


            <!-- TOMBOL -->

            <div class="buttons">


                <button
                    type="submit"
                    name="update"
                    class="btn update"
                >
                    Simpan Perubahan
                </button>


                <a
                    href="data_bmw.php?rt_id=<?= $rt_id ?>"
                    class="btn batal"
                >
                    Batal
                </a>


            </div>


        </form>


    </div>

</div>


</body>

</html>
```
